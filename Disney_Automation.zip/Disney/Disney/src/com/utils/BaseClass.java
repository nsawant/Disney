package com.utils;

import java.awt.AWTException;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.beans.PropertyChangeEvent;
import java.io.File;
import java.io.IOException;
import java.util.Properties;

import javax.imageio.ImageIO;

import org.apache.log4j.BasicConfigurator;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.internal.Configuration;

public class BaseClass {

	public static WebDriver driver;
	
	
	public static void Browser(String Select){
	BasicConfigurator.configure();
	
	switch(Select){
	case "chrome":
		System.setProperty("webdriver.chrome.driver", "C:\\Nilesh\\Selenium\\chromedriver_win32\\chromedriver.exe");
		ChromeOptions o = new ChromeOptions();
		o.addArguments("--disable-extensions");
		driver = new ChromeDriver();
		driver.navigate().to("Disney_url");
		break;
		
	case "firefox":
		System.setProperty("webdriver.gecko.driver", "C:\\Nilesh\\Selenium\\geckodriver-v0.19.1-win64\\geckodriver.exe");
		driver = new FirefoxDriver();
		break;
	}
	
	}
	@AfterMethod
	public static void screenshot() throws AWTException, IOException{
		Robot robot = new Robot();
		BufferedImage img = robot.createScreenCapture(new Rectangle(Toolkit.getDefaultToolkit().getScreenSize()));
		ImageIO.write(img, "png", new File("C:\\Nilesh\\Selenium" + System.currentTimeMillis() + "test.png"));
		
	}
	
	@AfterClass
	public static void CloseBrowser(){
		driver.close();
	}
		
}
