package com.utils;

public class LoggerExample {

	public LoggerExample() {
		// TODO Auto-generated constructor stub
	}

}
