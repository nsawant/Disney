package com.utils;

import org.apache.log4j.Logger;

public class LogClass {

	private static Logger Log = Logger.getLogger(LogClass.class.getName());

	public static void info(String message){
		
		Log.info(message);
	}
	
	public static void warn(String message){
		
		Log.warn(message);
	}
	
public static void error(String message){
		
		Log.error(message);
	}
}
