package com.poi;

import org.openqa.selenium.By;

public interface LoginPage{
	
	public By UserLogin = By.id("inputEmail");
	
	public By UserPassword = By.id("Password");
	
	public By LoginButton = By.id("submitButton");
	

}
