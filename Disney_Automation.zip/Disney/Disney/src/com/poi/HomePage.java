package com.poi;

import org.openqa.selenium.By;

public interface HomePage {
				
		public static By Logout = By.xpath("//*[@id='uam_modal']");
		
		public static By LogoutButton = By.id("logoutbutton");
		
		public static By PopUp = By.className("uam_blue");
		
		public static String LogoutXpected = "You have successfully logged out from all Single Sign-off enabled applications.";
			
		public static By LogoutActual = By.xpath("/html/body/form/div/div/div/div[2]/font");
		//public static By PopUp1 = By.xpath("/html/body/div/div/div[1]/div[2]/div/div[1]/form/table");		
		
		public static By GlobalESS = By.xpath("//*[@id='parentGroup_26']/div[1]/table/tbody/tr/td[1]/div/div[6]/div/a");
		
		public static By GESSHomepage = By.xpath("//*[@id='myWorklist']");
		
		public static By GlobalMain = By.xpath("//*[@id='parent_26']/a");
}
