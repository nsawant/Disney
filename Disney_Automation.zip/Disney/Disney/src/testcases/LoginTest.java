package testcases;

import org.testng.annotations.Parameters;
import org.apache.log4j.xml.DOMConfigurator;
import org.testng.annotations.Test;
import org.w3c.dom.DOMConfiguration;

import com.poi.HomePage;
import com.utils.BaseClass;
import functions.HomeFunctions;
import functions.LoginFunction;
import org.apache.commons.logging.Log;
import com.utils.LogClass;
public class LoginTest extends BaseClass{
	
	@Parameters({"Select", "User", "Pass"})
	@Test(priority=1)
	public void LoginTest1(String Select, String User, String Pass) throws Exception{
		
		DOMConfigurator.configure("log4j.xml");
		BaseClass.Browser(Select);
		
		LoginFunction.Username(User);
		LogClass.info("Username Found");
	
		LoginFunction.Password(Pass);
		LoginFunction.ClickOnLogin();
		
		HomeFunctions.LoginVerification();	
	}
	
	
	@Parameters({"Select", "User"})
	@Test(priority=4)
	public void NoPassword(String Select, String User) throws Exception{
		BaseClass.Browser(Select);
		LoginFunction.Username(User);
		LoginFunction.ClickOnLogin();
		LoginFunction.LoginButtonVerification();
		Thread.sleep(1000);
		
	}
	
	
	@Parameters({"Pass"})
	@Test(priority=5)
	public void NoUsername(String Pass) throws Exception{
		LoginFunction.Clear();
		LoginFunction.Password(Pass);
		LoginFunction.ClickOnLogin();
		LoginFunction.LoginButtonVerification();
	}


}
