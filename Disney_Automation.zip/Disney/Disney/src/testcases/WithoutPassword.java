package testcases;

import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.poi.LoginPage;
import com.utils.BaseClass;

import functions.*;
public class WithoutPassword extends BaseClass implements LoginPage{

	@Parameters({"Select", "User"})
	@Test(priority=7, groups="regression")
		public static void LoginWithoutPassword(String User, String Select) throws Exception{
		BaseClass.Browser(Select);
		LoginFunction.Username(User);
		LoginFunction.ClickOnLogin();
		LoginFunction.ErrorVerfication();
	}
	
	

}
