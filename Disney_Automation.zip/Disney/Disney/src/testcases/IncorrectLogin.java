package testcases;

import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.poi.LoginPage;
import com.utils.BaseClass;

import functions.LoginFunction;

public class IncorrectLogin extends BaseClass {

	@Test(priority=6)
	@Parameters({"Select", "User", "Pass"})
	public void IncorrectLoginTest(String Select, String User, String Pass) throws Exception {
		// TODO Auto-generated constructor stub
		BaseClass.Browser(Select);
		LoginFunction.Username(User);
		LoginFunction.Password(Pass);
		LoginFunction.ClickOnLogin();
		LoginFunction.ErrorVerfication();
	}

}
