package functions;

import static org.testng.Assert.assertTrue;

import javax.swing.text.StyledEditorKit.BoldAction;

import org.apache.http.util.Asserts;
import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import com.poi.LoginPage;
import com.utils.BaseClass;

public class LoginFunction extends BaseClass implements LoginPage{

	
	public void Openurl(String url) throws InterruptedException {
		driver.get(url);
		Thread.sleep(1000);
	}
	
	public static void Username(String User){
		driver.findElement(UserLogin).clear();
		driver.findElement(UserLogin).sendKeys(User);
	}
	
	public static void Password(String Pass){
		driver.findElement(UserPassword).sendKeys(Pass);
	}
	
	public static void LoginButtonVerification(){
		boolean loginbuttonstatus = driver.findElement(LoginButton).isDisplayed();
		assertTrue(loginbuttonstatus);
	}
	
	public static void ClickOnLogin() throws Exception{
		driver.findElement(LoginButton).click();
		Thread.sleep(10000);
	}
	
	public static void Clear(){
		driver.findElement(UserLogin).clear();
		
	}
	
	public static void ErrorVerfication(){
		boolean ErrorVerfication = driver.findElement(Error).isDisplayed();
		try{
		assertTrue(ErrorVerfication);
		System.out.println("Error message VErified" + ErrorVerfication);
		}catch (Exception e){
			System.out.println(e);
		}
	}
}
